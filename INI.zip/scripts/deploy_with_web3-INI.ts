import { deploy } from './web3-lib'

(async () => {
  try {
    const result = await deploy('INI', ["INI", "INI", 12, 12000000000000])
    console.log(`address: ${result.address}`)
  } catch (e) {
    console.log(e.message)
  }
})()